// dllmain.h : ��� Ŭ������ �����Դϴ�.

class CSansuServerModule : public ATL::CAtlDllModuleT< CSansuServerModule >
{
public :
	DECLARE_LIBID(LIBID_SansuServerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_SANSUSERVER, "{EC4C10CE-B7A7-4453-A34D-FC02D13C2992}")
};

extern class CSansuServerModule _AtlModule;
