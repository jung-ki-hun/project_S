

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Mon Jun 08 18:53:43 2020
 */
/* Compiler settings for MyMul.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __MyMul_i_h__
#define __MyMul_i_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IMyMul_FWD_DEFINED__
#define __IMyMul_FWD_DEFINED__
typedef interface IMyMul IMyMul;

#endif 	/* __IMyMul_FWD_DEFINED__ */


#ifndef __ISansu_FWD_DEFINED__
#define __ISansu_FWD_DEFINED__
typedef interface ISansu ISansu;

#endif 	/* __ISansu_FWD_DEFINED__ */


#ifndef __MyMul_FWD_DEFINED__
#define __MyMul_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyMul MyMul;
#else
typedef struct MyMul MyMul;
#endif /* __cplusplus */

#endif 	/* __MyMul_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IMyMul_INTERFACE_DEFINED__
#define __IMyMul_INTERFACE_DEFINED__

/* interface IMyMul */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IMyMul;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F506B071-3269-42BD-A9E4-A7602D0231F4")
    IMyMul : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Mul( 
            /* [in] */ int a,
            /* [in] */ int b,
            /* [out] */ int *c) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IMyMulVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IMyMul * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IMyMul * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IMyMul * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IMyMul * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IMyMul * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IMyMul * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IMyMul * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Mul )( 
            IMyMul * This,
            /* [in] */ int a,
            /* [in] */ int b,
            /* [out] */ int *c);
        
        END_INTERFACE
    } IMyMulVtbl;

    interface IMyMul
    {
        CONST_VTBL struct IMyMulVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMyMul_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IMyMul_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IMyMul_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IMyMul_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IMyMul_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IMyMul_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IMyMul_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IMyMul_Mul(This,a,b,c)	\
    ( (This)->lpVtbl -> Mul(This,a,b,c) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IMyMul_INTERFACE_DEFINED__ */


#ifndef __ISansu_INTERFACE_DEFINED__
#define __ISansu_INTERFACE_DEFINED__

/* interface ISansu */
/* [unique][uuid][object] */ 


EXTERN_C const IID IID_ISansu;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("3886E0A8-FC55-4254-8F1B-57DF1538F774")
    ISansu : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Add( 
            /* [in] */ int a,
            /* [in] */ int b,
            /* [retval][out] */ int *c) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct ISansuVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISansu * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISansu * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISansu * This);
        
        HRESULT ( STDMETHODCALLTYPE *Add )( 
            ISansu * This,
            /* [in] */ int a,
            /* [in] */ int b,
            /* [retval][out] */ int *c);
        
        END_INTERFACE
    } ISansuVtbl;

    interface ISansu
    {
        CONST_VTBL struct ISansuVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISansu_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ISansu_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ISansu_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ISansu_Add(This,a,b,c)	\
    ( (This)->lpVtbl -> Add(This,a,b,c) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ISansu_INTERFACE_DEFINED__ */



#ifndef __MyMulLib_LIBRARY_DEFINED__
#define __MyMulLib_LIBRARY_DEFINED__

/* library MyMulLib */
/* [version][uuid] */ 


EXTERN_C const IID LIBID_MyMulLib;

EXTERN_C const CLSID CLSID_MyMul;

#ifdef __cplusplus

class DECLSPEC_UUID("9EA98D19-5B7D-4DC4-B072-716776626053")
MyMul;
#endif
#endif /* __MyMulLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


