// dllmain.h : ��� Ŭ������ �����Դϴ�.

class CAddServerModule : public ATL::CAtlDllModuleT< CAddServerModule >
{
public :
	DECLARE_LIBID(LIBID_AddServerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_ADDSERVER, "{5DAA9349-10C1-4FA2-BEA0-7CDE4C74361A}")
};

extern class CAddServerModule _AtlModule;
