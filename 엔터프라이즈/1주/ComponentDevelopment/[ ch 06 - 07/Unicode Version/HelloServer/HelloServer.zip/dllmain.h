// dllmain.h : ��� Ŭ������ �����Դϴ�.

class CHelloServerModule : public CAtlDllModuleT< CHelloServerModule >
{
public :
	DECLARE_LIBID(LIBID_HelloServerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_HELLOSERVER, "{A00F1861-729E-42C5-8382-214584DB298B}")
};

extern class CHelloServerModule _AtlModule;
